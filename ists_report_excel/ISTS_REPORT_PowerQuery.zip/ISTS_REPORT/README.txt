ISTS REPORT - POWER QUERY VERSION (no macro)
============================================

1) FOLDER ORGANISATION (one time only)
--------------------------------------
Extract this zip directly to drive C: (right-click the zip > "Extract All..." >
type  C:\  > Extract). You get:

    C:\ISTS_REPORT\
        ISTS_Report_PowerQuery.xlsx      <- the report (open this file)
        README.txt                       <- this file
        PowerQuery_Queries.txt           <- the Power Query code (reference)
        CSV\
            TRANSPORT\                   <- put the "transport" CSV (samples / results) here
            REJECTIONS\                  <- put the "rejections" CSV here
        SAMPLE_DATA\                     <- 2 fictitious CSV files for a test run

Rules:
  - CSV file names do not matter. In each folder, the MOST RECENT .csv file
    (date modified) is used.
  - Do not rename the columns of the exported CSV.
  - Do not rename the TRANSPORT and REJECTIONS folders.
  - Move old CSV files somewhere else (e.g. C:\ISTS_REPORT\ARCHIVE\).

Want another location than C:\ISTS_REPORT ?
  Open the report > Data > Queries & Connections > right-click
  "Parameters" > Edit > Home > Advanced Editor, and change the line
      Folder = "C:\ISTS_REPORT\CSV",
  then Close & Load.

2) FIRST OPENING
----------------
  - If Windows blocked the downloaded file: right-click
    ISTS_Report_PowerQuery.xlsx > Properties > tick "Unblock" > OK.
  - When opening, click "Enable Editing", then "Enable Content" if Excel says
    that data connections have been disabled.
  - If Excel asks about "privacy levels", choose "Ignore Privacy Levels checks"
    (or "Organizational").

Test run: copy the 2 files from SAMPLE_DATA into CSV\TRANSPORT and CSV\REJECTIONS
(transport_... into TRANSPORT, rejections_... into REJECTIONS), open the report,
then Data > Refresh All. Delete them afterwards.

3) EVERY MONTH
--------------
  1. Put the new transport CSV in CSV\TRANSPORT and the rejections CSV
     in CSV\REJECTIONS.
  2. Open ISTS_Report_PowerQuery.xlsx: it refreshes automatically when opened.
     (Otherwise: Data > Refresh All.)
  3. Sheets 1_ to 14_ contain Tables 1 to 16 and Figures 1 to 10.
  4. Save a copy of the monthly report if you want to archive it
     (File > Save As).

Reporting month = latest month found in the CSV (custom_month period,
e.g. 26/08 to 25/09 = September), compared with the previous month.
Tables are built by Region if the CSV contains several regions,
otherwise by District.

4) TROUBLESHOOTING
------------------
  "No .csv file found in folder ..."  -> the CSV is not in the right folder.
  "DataSource.NotFound" / "Could not find a part of the path" -> the folder
       C:\ISTS_REPORT\CSV does not exist (see point 1).
  Empty or shifted columns -> the CSV separator is not a comma:
       edit the line  Separator = ","  of the Parameters query (see point 1).
