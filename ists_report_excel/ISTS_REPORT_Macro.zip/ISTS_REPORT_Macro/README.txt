ISTS REPORT - MACRO VERSION (.xlsm)
===================================

FOLDER CONTENTS
---------------
    ISTS_REPORT_Macro\
        ISTS_Report_Macro.xlsm       <- the report with the import button (open this file)
        README.txt                   <- this file
        SAMPLE_DATA\                 <- 2 fictitious CSV files for a test run
        BACKUP\                      <- use only if the macro does not load

You can put this folder anywhere (Desktop, Documents...).
The CSV files can be anywhere too: you select them with the button.

1) FIRST OPENING (one time only)
--------------------------------
  1. Windows blocks macros in downloaded files. Before opening:
     right-click ISTS_Report_Macro.xlsm > Properties > tick "Unblock" > OK.
  2. Open the file, then click "Enable Editing" and "Enable Content".
  3. If Excel asks about "privacy levels", choose "Ignore Privacy Levels checks"
     (or "Organizational").

2) EVERY MONTH
--------------
  1. Home sheet: click the blue button
     "Import CSV files and build the report".
  2. Select the TRANSPORT CSV first, then the REJECTIONS CSV.
  3. Wait for the message "Report updated": sheets 1_ to 14_ are ready
     (Tables 1 to 16, Figures 1 to 10).
  4. File > Save As to keep a copy of the monthly report.

  No button? Press Alt+F8 > ImportCSV > Run.
  The green button "Refresh report" runs the update again with the same CSV
  files (useful after changing a yellow setting on the Home sheet:
  reporting month, Region/District level, separator, sites for rejections).

  Test run: use the 2 files in the SAMPLE_DATA folder.

3) IF THE MACRO DOES NOT LOAD (backup plan)
-------------------------------------------
  If Excel says the file was repaired and the VBA project was removed,
  or if Alt+F8 does not list "ImportCSV":
  1. Open BACKUP\ISTS_Report_Macro_no_code.xlsx
  2. Alt+F11 > File > Import File > BACKUP\ImportModule.bas
  3. Close the editor, File > Save As > type
     "Excel Macro-Enabled Workbook (*.xlsm)".
  4. Alt+F8 > InstallButtons > Run (adds the buttons on the Home sheet).
